Supplementary material for the workshop paper.
Existing study artifacts copied without modification; see MANIFEST.json.
Smoke/pilot/probes remain ineligible for main inference.
The decision log records the pilot amendment and approved main-execution deviation.
